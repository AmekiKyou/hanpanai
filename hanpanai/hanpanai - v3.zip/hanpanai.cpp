//Greedy Hanpanaitte

#include<iostream>
#include<utility>
#include<vector>
#include<cmath>

namespace PlayBoard{

class PlayBoard{
 private:
   int Board[5][5];
 public:
   PlayBoard(){
     for (int i=0;i<5;++i)
      for (int j=0;j<5;++j) Board[i][j]=0;
   }

   void update(int updated[5][5]){
     for (int i=0;i<5;++i)
      for (int j=0;j<5;++j) Board[i][j]=updated[i][j];
   }

   std::pair<char,int> move(int level){
     // If you can merge this turn, do not merge in the next turn
     // Merge more, not merge bigger!
     // level: 0 or 1, I am not to predict 2 turns later...

     std::pair<char,int> ret(char(0),-1);
     int winchance=0;

     {
       int board[5][5];
       for (int i=0;i<5;++i)
        for (int j=0;j<5;++j) board[i][j]=Board[i][j];
       bool moved=false,standby[5]={true,true,true,true,true};
       int merge=0;
       for (int i=0;i<5;++i)
        for (int j=0;j<5;++j)
          if (board[i][j]){
            int k=j;
            while (k>0&&!board[i][k-1]){
              moved=true;
              std::swap(board[i][k-1],board[i][k]);
              --k;
            }
            if (k>0&&standby[i]&&board[i][k-1]==board[i][k]){
              moved=true;
              standby[i]=false;
              board[i][k]=0;
              ++board[i][k-1];
              ++merge;
            }
            else standby[i]=true;
          }
       if (moved){
         if (merge>=ret.second){
           std::pair<char,int> secres('\0',0);
           if (level==0){
             PlayBoard board_tmp;
             board_tmp.update(board);
             secres=board_tmp.move(level+1);
           }
           if (merge>ret.second){
             winchance=secres.second;
             ret.second=merge;
             ret.first='L';
           }
           else if (secres.second>winchance){
             winchance=secres.second;
             ret.second=merge;
             ret.first='L';
           }
         }
         /*
         std::cout<<"L slash: "<<merge<<std::endl;
         for (int i=0;i<5;++i){
           for (int j=0;j<5;++j) std::cout<<board[i][j]<<' ';
           std::cout<<std::endl;
         }
         */
       }
     }// L

     {
       int board[5][5];
       for (int i=0;i<5;++i)
        for (int j=0;j<5;++j) board[i][j]=Board[i][j];
       bool moved=false,standby[5]={true,true,true,true,true};
       int merge=0;
       for (int i=0;i<5;++i)
        for (int j=4;j>=0;--j)
          if (board[i][j]){
            int k=j;
            while (k<4&&!board[i][k+1]){
              moved=true;
              std::swap(board[i][k+1],board[i][k]);
              ++k;
            }
            if (k<4&&standby[i]&&board[i][k+1]==board[i][k]){
              moved=true;
              standby[i]=false;
              board[i][k]=0;
              ++board[i][k+1];
              ++merge;
            }
            else standby[i]=true;
          }
       if (moved){
         if (merge>=ret.second){
           std::pair<char,int> secres('\0',0);
           if (level==0){
             PlayBoard board_tmp;
             board_tmp.update(board);
             secres=board_tmp.move(level+1);
           }
           if (merge>ret.second){
             winchance=secres.second;
             ret.second=merge;
             ret.first='R';
           }
           else if (secres.second>winchance){
             winchance=secres.second;
             ret.second=merge;
             ret.first='R';
           }
         }
         /*
         std::cout<<"R slash: "<<merge<<std::endl;
         for (int i=0;i<5;++i){
           for (int j=0;j<5;++j) std::cout<<board[i][j]<<' ';
           std::cout<<std::endl;
         }
         */
       }
     }// R

     {
       int board[5][5];
       for (int i=0;i<5;++i)
        for (int j=0;j<5;++j) board[i][j]=Board[i][j];
       bool moved=false,standby[5]={true,true,true,true,true};
       int merge=0;
       for (int j=0;j<5;++j)
        for (int i=0;i<5;++i)
          if (board[i][j]){
            int k=i;
            while (k>0&&!board[k-1][j]){
              moved=true;
              std::swap(board[k-1][j],board[k][j]);
              --k;
            }
            if (k>0&&standby[j]&&board[k-1][j]==board[k][j]){
              moved=true;
              standby[j]=false;
              board[k][j]=0;
              ++board[k-1][j];
              ++merge;
            }
            else standby[j]=true;
          }
       if (moved){
         if (merge>=ret.second){
           std::pair<char,int> secres('\0',0);
           if (level==0){
             PlayBoard board_tmp;
             board_tmp.update(board);
             secres=board_tmp.move(level+1);
           }
           if (merge>ret.second){
             winchance=secres.second;
             ret.second=merge;
             ret.first='U';
           }
           else if (secres.second>winchance){
             winchance=secres.second;
             ret.second=merge;
             ret.first='U';
           }
         }
         /*
         std::cout<<"U slash: "<<merge<<std::endl;
         for (int i=0;i<5;++i){
           for (int j=0;j<5;++j) std::cout<<board[i][j]<<' ';
           std::cout<<std::endl;
         }
         */
       }
     }// U

     {
       int board[5][5];
       for (int i=0;i<5;++i)
        for (int j=0;j<5;++j) board[i][j]=Board[i][j];
       bool moved=false,standby[5]={true,true,true,true,true};
       int merge=0;
       for (int j=0;j<5;++j)
        for (int i=4;i>=0;--i)
          if (board[i][j]){
            int k=i;
            while (k<4&&!board[k+1][j]){
              moved=true;
              std::swap(board[k+1][j],board[k][j]);
              ++k;
            }
            if (k<4&&standby[j]&&board[k+1][j]==board[k][j]){
              moved=true;
              standby[j]=false;
              board[k][j]=0;
              ++board[k+1][j];
              ++merge;
            }
            else standby[j]=true;
          }
       if (moved){
         if (merge>=ret.second){
           std::pair<char,int> secres('\0',0);
           if (level==0){
             PlayBoard board_tmp;
             board_tmp.update(board);
             secres=board_tmp.move(level+1);
           }
           if (merge>ret.second){
             winchance=secres.second;
             ret.second=merge;
             ret.first='D';
           }
           else if (secres.second>winchance){
             winchance=secres.second;
             ret.second=merge;
             ret.first='D';
           }
         }
         /*
         std::cout<<"D slash: "<<merge<<std::endl;
         for (int i=0;i<5;++i){
           for (int j=0;j<5;++j) std::cout<<board[i][j]<<' ';
           std::cout<<std::endl;
         }
         */
       }
     }// D

     return ret;
   }

   std::vector<std::pair<int,int>> put(int x){
     // somewhat Prim-like strategy
     // to-do: optimize the situation where several candidates can have the same degree

     std::vector<std::pair<int,int>> ret;
     std::vector<std::pair<int,int>> slot;
     for (int i=0;i<5;++i)
      for (int j=0;j<5;++j)
        if (Board[i][j]==0) slot.push_back(std::make_pair(i,j));
     int winchance=10000;
     // This is for enemy (times to merge), make it smaller
     for (int v=x;v>=1;--v){
       int num_put=1<<(x-v);
       if (num_put>slot.size()) break;
       int board[5][5];
       for (int i=0;i<5;++i)
        for (int j=0;j<5;++j) board[i][j]=Board[i][j];
       std::vector<std::pair<int,int>> slot_tmp=slot;
       std::vector<std::pair<int,int>> gulag_list;
       while (num_put--){
         int minnxt=10000;
         std::pair<int,int> victim;
         for (std::pair<int,int> candidate:slot_tmp){
           int x=candidate.first,y=candidate.second;
           if (board[x][y]) continue;
           int nxt=0;
           {
             bool same=false;
             for (int i=y-1;i>=0;--i)
              if (board[x][i]){
                if (board[x][i]==v) same=true;
                break;
              }
             if (same) ++nxt;
           }
           {
             bool same=false;
             for (int i=y+1;i<5;++i)
              if (board[x][i]){
                if (board[x][i]==v) same=true;
                break;
              }
             if (same) ++nxt;
           }
           {
             bool same=false;
             for (int i=x-1;i>=0;--i)
              if (board[i][y]){
                if (board[i][y]==v) same=true;
                break;
              }
             if (same) ++nxt;
           }
           {
             bool same=false;
             for (int i=x+1;i<5;++i)
              if (board[i][y]){
                if (board[i][y]==v) same=true;
                break;
              }
             if (same) ++nxt;
           }
           if (nxt<minnxt){
             minnxt=nxt;
             victim=candidate;
           }
           // not considered what if nxt==minnxt
         }
         board[victim.first][victim.second]=v;
         gulag_list.push_back(victim);
       }
       PlayBoard board_tmp;
       board_tmp.update(board);
       std::pair<char,int> moveres=board_tmp.move(0);
       if (moveres.second<winchance){
         winchance=moveres.second;
         ret=gulag_list;
       }
     }
     return ret;
   }
};

};

int main (void){
  int player;
  std::cin>>player;
  if (player) std::cout<<"3 3"<<std::endl;
  else std::cout<<"2 2"<<std::endl;
  // No meaning, just for fun

  int turn, timeleft, score_me, score_rival;
  int board_me[5][5], board_rival[5][5];
  PlayBoard::PlayBoard me, rival;
  std::pair<char,int> moveres;
  std::vector<std::pair<int,int>> putres;
  while (true){
    std::cin>>turn>>timeleft>>score_me>>score_rival;
    for (int i=0;i<5;++i)
      for (int j=0;j<5;++j) std::cin>>board_me[i][j];
    for (int i=0;i<5;++i)
      for (int j=0;j<5;++j) std::cin>>board_rival[i][j];
    me.update(board_me);
    rival.update(board_rival);
    moveres=me.move(0);
    if (moveres.first){
      putres=rival.put(moveres.second+1);
      int m=putres.size();
      int v=1+moveres.second-log2(m);
      std::cout<<moveres.first<<" "<<m<<" "<<v;
      for (auto i: putres) std::cout<<" "<<i.first+1<<" "<<i.second+1;
      std::cout<<std::endl;
    }
    else{
      std::cout<<"Kill me!"<<std::endl;
      break;
    }
  }
  return 0;
}
