g++ hanpanai.cpp -o a.out -O2 --std=c++17

